package shipWeapons;

public enum WeaponType {
	BEAM,PROJECTILE,MISSILE,AOE,TORPEDO,SPECIAL,

}
