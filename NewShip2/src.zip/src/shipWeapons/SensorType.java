package shipWeapons;

public enum SensorType {
	ACTIVE,PASSIVE,REMOTE,

}
