package shipWeapons;

public enum MiscellaneousType {
	HANGER,ACCOM,CARGO,FUEL,MISC,POWER,CMD,ENGINE
}
